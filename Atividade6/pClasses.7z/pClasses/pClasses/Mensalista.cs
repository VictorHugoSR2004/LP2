﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pClasses
{
    internal class Mensalista : Empregado
    {
        public double SalarioMensal { get; set; }

        public override double SalarioBruto()
        {
            return SalarioMensal;
        }
        public Mensalista()
        {
            System.Windows.Forms.MessageBox.Show("Aqui é Mensalista");
        }
        public Mensalista (int mat, string nome, DateTime datax, double salx)
        {
            this.Matricula = mat;
            this.NomeEmpregado = nome;
            this.DataEntradaEmpresa = datax;
            this.SalarioMensal = salx;
        }

        public static String Empresa = "Toyota";
        public const String Filial = "Filial Sorocaba";


    }
}
