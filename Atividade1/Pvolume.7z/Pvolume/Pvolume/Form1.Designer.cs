﻿namespace Pvolume
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            lblRaio = new Label();
            lblAltura = new Label();
            lblVolume = new Label();
            txtRaio = new TextBox();
            txtAltura = new TextBox();
            txtVolume = new TextBox();
            btnCalcular = new Button();
            btnFechar = new Button();
            SuspendLayout();
            // 
            // lblRaio
            // 
            lblRaio.AutoSize = true;
            lblRaio.Location = new Point(74, 54);
            lblRaio.Margin = new Padding(4, 0, 4, 0);
            lblRaio.Name = "lblRaio";
            lblRaio.Size = new Size(43, 21);
            lblRaio.TabIndex = 0;
            lblRaio.Text = "Raio";
            // 
            // lblAltura
            // 
            lblAltura.AutoSize = true;
            lblAltura.Location = new Point(74, 101);
            lblAltura.Margin = new Padding(4, 0, 4, 0);
            lblAltura.Name = "lblAltura";
            lblAltura.Size = new Size(51, 21);
            lblAltura.TabIndex = 1;
            lblAltura.Text = "Altura";
            // 
            // lblVolume
            // 
            lblVolume.AutoSize = true;
            lblVolume.Location = new Point(74, 153);
            lblVolume.Margin = new Padding(4, 0, 4, 0);
            lblVolume.Name = "lblVolume";
            lblVolume.Size = new Size(64, 21);
            lblVolume.TabIndex = 2;
            lblVolume.Text = "Volume";
            // 
            // txtRaio
            // 
            txtRaio.Location = new Point(151, 54);
            txtRaio.Margin = new Padding(4);
            txtRaio.Name = "txtRaio";
            txtRaio.Size = new Size(128, 29);
            txtRaio.TabIndex = 3;
            txtRaio.Validated += txtRaio_Validated;
            // 
            // txtAltura
            // 
            txtAltura.Location = new Point(151, 101);
            txtAltura.Margin = new Padding(4);
            txtAltura.Name = "txtAltura";
            txtAltura.Size = new Size(128, 29);
            txtAltura.TabIndex = 4;
            txtAltura.Validated += txtAltura_Validated;
            // 
            // txtVolume
            // 
            txtVolume.Enabled = false;
            txtVolume.ForeColor = SystemColors.Window;
            txtVolume.Location = new Point(151, 153);
            txtVolume.Margin = new Padding(4);
            txtVolume.Name = "txtVolume";
            txtVolume.Size = new Size(128, 29);
            txtVolume.TabIndex = 5;
            // 
            // btnCalcular
            // 
            btnCalcular.BackgroundImage = (Image)resources.GetObject("btnCalcular.BackgroundImage");
            btnCalcular.Font = new Font("Arial Unicode MS", 12.25F, FontStyle.Italic);
            btnCalcular.Location = new Point(172, 295);
            btnCalcular.Margin = new Padding(4);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(205, 96);
            btnCalcular.TabIndex = 6;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnFechar
            // 
            btnFechar.BackColor = SystemColors.InfoText;
            btnFechar.BackgroundImage = (Image)resources.GetObject("btnFechar.BackgroundImage");
            btnFechar.BackgroundImageLayout = ImageLayout.Center;
            btnFechar.Location = new Point(521, 295);
            btnFechar.Margin = new Padding(4);
            btnFechar.Name = "btnFechar";
            btnFechar.Size = new Size(205, 96);
            btnFechar.TabIndex = 7;
            btnFechar.Text = "Fechar";
            btnFechar.UseVisualStyleBackColor = false;
            btnFechar.Click += btnFechar_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(9F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(889, 456);
            Controls.Add(btnFechar);
            Controls.Add(btnCalcular);
            Controls.Add(txtVolume);
            Controls.Add(txtAltura);
            Controls.Add(txtRaio);
            Controls.Add(lblVolume);
            Controls.Add(lblAltura);
            Controls.Add(lblRaio);
            Font = new Font("Arial Unicode MS", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            Margin = new Padding(4);
            Name = "Form1";
            Text = "Calcular o Volume";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblRaio;
        private Label lblAltura;
        private Label lblVolume;
        private TextBox txtRaio;
        private TextBox txtAltura;
        private TextBox txtVolume;
        private Button btnCalcular;
        private Button btnFechar;
    }
}
