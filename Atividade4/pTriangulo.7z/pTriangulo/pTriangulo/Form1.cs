﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pTriangulo
{
    public partial class Form1 : Form
    {
        double A, B, C;
        string Resultado, ValorA, ValorB, ValorC;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Text = "";
            txtLadoB.Text = "";
            txtLadoC.Text = "";
            A = 0;
            B = 0;
            C = 0;
            lblResultado.Text = "";
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            try
            {
                ValorA = txtLadoA.Text;
                ValorB = txtLadoB.Text;
                ValorC = txtLadoC.Text;

                if (string.IsNullOrEmpty(ValorA) || string.IsNullOrEmpty(ValorB) || string.IsNullOrEmpty(ValorC))
                {
                    MessageBox.Show("Insira algum valor!!", "Atenção",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    A = double.Parse(txtLadoA.Text);
                    B = double.Parse(txtLadoB.Text);
                    C = double.Parse(txtLadoC.Text);

                    if (A == 0 || B == 0 || C == 0)
                    {
                        Resultado = "Os valores devem ser maiores que 0";
                        lblResultado.Text = Resultado;
                    }
                    else if (A + B < C)
                    {
                        Resultado = "Não é um triângulo, pois A+B<C";
                        lblResultado.Text = Resultado;
                    }
                    else if (A + C < B)
                    {
                        Resultado = "Não é um triângulo, pois A+C<B";
                        lblResultado.Text = Resultado;
                    }
                    else if (B + C < A)
                    {
                        Resultado = "Não é um triângulo, pois B+C<A";
                        lblResultado.Text = Resultado;
                    }
                    else if (A == B && A == C)
                    {
                        Resultado = "Seu triângulo é equilátero";
                        lblResultado.Text = Resultado;
                    }
                    else if (A == B || A == C || C == B)
                    {
                        Resultado = "Seu triângulo é isóceles";
                        lblResultado.Text = Resultado;
                    }
                    else if (A != B || A != C || C != B)
                    {
                        Resultado = "Seu triângulo é escaleno";
                        lblResultado.Text = Resultado;
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Utilize apenas números!!", "Atenção",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
