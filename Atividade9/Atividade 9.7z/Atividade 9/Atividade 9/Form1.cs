﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Atividade_9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
        private int GetNValue()
        {
            int ultimoDigitoRA = 7;
            int N;

            if (ultimoDigitoRA == 0)
            {
                N = 10;
            }
            else
            {
                N = ultimoDigitoRA;
            }

            return N;
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            string saida = "";

            for (var i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox($"Digite um nº para posição: {i + 1}");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido!");
                    i--;
                }
                else
                {
                    saida = vetor[i] + "\n" + saida;
                }
            }
            MessageBox.Show(saida);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList();
            alunos.Add("Ana");
            alunos.Add("André");
            alunos.Add("Débora");
            alunos.Add("Fátima");
            alunos.Add("João");
            alunos.Add("Janete");
            alunos.Add("Otávio");
            alunos.Add("Marcelo");
            alunos.Add("Pedro");
            alunos.Add("Thais");

            alunos.Remove("Otávio");

            string resultado = "Alunos:\n";
            foreach (string aluno in alunos)
            {
                resultado += aluno + "\n";
            }
            MessageBox.Show(resultado);
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[3, 3];
            string auxiliar = "";
            string saida = "";
            double media;


            for (int aluno = 0; aluno < 3; aluno++)
            {
                double somamedia = 0;
                for (int nota = 0; nota < 3; nota++)
                {

                    auxiliar = Interaction.InputBox($"Digite a nota do aluno {aluno + 1} para a nota {nota + 1}");
                    if (!double.TryParse(auxiliar, out notas[aluno, nota]) || (notas[aluno, nota] < 0) || (notas[aluno, nota] > 10))
                    {


                        MessageBox.Show("Número inválido!");
                        nota--;

                    }
                    else
                    {
                        somamedia += notas[aluno, nota];
                    }
                }


                media = somamedia / 3;

                saida = saida + "Média do Aluno " + (aluno + 1) + ":" + media.ToString("N2") + "\n";
            }
            MessageBox.Show(saida);
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            Form2 Frm2 = new Form2();
            Frm2.Show();
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            Form3 Frm3 = new Form3();
            Frm3.Show();
        }
    }
}
