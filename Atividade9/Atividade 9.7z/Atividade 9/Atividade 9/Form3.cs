﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_9
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
        private int GetNValue()
        {
            int ultimoDigitoRA = 7;
            int N;

            if (ultimoDigitoRA == 0)
            {
                N = 10;
            }
            else
            {
                N = ultimoDigitoRA;
            }

            return N;
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            // Gabarito com 10 questões
            string[] gabarito = { "A", "B", "C", "D", "E", "A", "B", "C", "D", "E" };

            // Valor de N baseado no RA (RA = 7)
            int n = GetNValue();
            string[,] respostasAlunos = new string[n, 10];

            // Coletar respostas
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    string resposta;
                    do
                    {
                        resposta = Microsoft.VisualBasic.Interaction.InputBox(
                            $"Digite a resposta do aluno {i + 1} para a questão {j + 1} (A, B, C, D ou E):",
                            "Entrada de Resposta"
                        ).ToUpper();
                    } while (!(resposta == "A" || resposta == "B" || resposta == "C" || resposta == "D" || resposta == "E"));

                    respostasAlunos[i, j] = resposta;
                }
            }

            // Mostrar resultados
            listBoxResultados.Items.Clear();
            for (int i = 0; i < n; i++)
            {
                int acertos = 0;
                for (int j = 0; j < 10; j++)
                {
                    if (respostasAlunos[i, j] == gabarito[j])
                    {
                        acertos++;
                        listBoxResultados.Items.Add($"Aluno {i + 1}: Acertou a questão {j + 1}");
                    }
                }
                listBoxResultados.Items.Add($"Aluno {i + 1}: {acertos} acertos\n");
                listBoxResultados.Items.Add("");
            }
            
        }
    }
}
