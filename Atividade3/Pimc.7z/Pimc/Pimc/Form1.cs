﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        double Peso, Altura, IMC;
        string Classe;
        public Form1()
        {
            InitializeComponent();
        }


        private void mskbxPeso_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(mskbxPeso.Text, out Peso))
            {
                MessageBox.Show("Insira um valor.", "Atenção",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                e.Cancel = true;
                mskbxPeso.Focus();
            }
        }

        private void mskbxAltura_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(mskbxAltura.Text, out Altura))
            {
                MessageBox.Show("Insira um valor.", "Atenção",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                e.Cancel = true;
                mskbxAltura.Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (Peso == 0 || Altura == 0)
            {
                MessageBox.Show("Peso e Altura deve ser maior que zero!");
                mskbxPeso.Focus();
            }
            else
            {
                IMC = Peso / Math.Pow(Altura, 2);
                IMC = Math.Round(IMC, 1);
                txtIMC.Text = IMC.ToString();
            }
            
            if(IMC < 18.5)
            {
                Classe = "Magreza";
                lblClasse.Text = Classe;
            }
            else if (IMC >= 18.5 && IMC <=24.9)
            {
                Classe = "Normal";
                lblClasse.Text = Classe;
            }
            else if (IMC >= 25.0 && IMC <= 29.9)
            {
                Classe = "Sobrepeso";
                lblClasse.Text = Classe;
            }
            else if (IMC >= 29.9 && IMC <= 39.9)
            {
                Classe = "Obesidade";
                lblClasse.Text = Classe;
            }
            else if (IMC > 40.0)
            {
                Classe = "Obesidade Grave";
                lblClasse.Text = Classe;
            }

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxPeso.Text = "";
            mskbxAltura.Text = "";
            txtIMC.Text = "";
            Peso = 0;
            Altura = 0;
            IMC= 0;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }



    }
}
