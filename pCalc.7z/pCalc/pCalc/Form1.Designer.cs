﻿namespace pCalc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnLimpar = new Button();
            btnSair = new Button();
            btnAdd = new Button();
            btnSub = new Button();
            btnMulti = new Button();
            btnDiv = new Button();
            lblNum1 = new Label();
            lblNum2 = new Label();
            lblResult = new Label();
            txtNum1 = new TextBox();
            txtNum2 = new TextBox();
            txtResult = new TextBox();
            SuspendLayout();
            // 
            // btnLimpar
            // 
            btnLimpar.Font = new Font("Segoe UI", 12F);
            btnLimpar.Location = new Point(377, 50);
            btnLimpar.Margin = new Padding(4);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(118, 77);
            btnLimpar.TabIndex = 7;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Font = new Font("Segoe UI", 12F);
            btnSair.Location = new Point(377, 143);
            btnSair.Margin = new Padding(4);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(118, 77);
            btnSair.TabIndex = 8;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // btnAdd
            // 
            btnAdd.Font = new Font("Segoe UI", 12F);
            btnAdd.Location = new Point(31, 272);
            btnAdd.Margin = new Padding(4);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(82, 52);
            btnAdd.TabIndex = 3;
            btnAdd.Text = "+";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnSub
            // 
            btnSub.Font = new Font("Segoe UI", 12F);
            btnSub.Location = new Point(141, 272);
            btnSub.Margin = new Padding(4);
            btnSub.Name = "btnSub";
            btnSub.Size = new Size(82, 52);
            btnSub.TabIndex = 4;
            btnSub.Text = "-";
            btnSub.UseVisualStyleBackColor = true;
            btnSub.Click += btnSub_Click;
            // 
            // btnMulti
            // 
            btnMulti.Font = new Font("Segoe UI", 12F);
            btnMulti.Location = new Point(248, 272);
            btnMulti.Margin = new Padding(4);
            btnMulti.Name = "btnMulti";
            btnMulti.Size = new Size(82, 52);
            btnMulti.TabIndex = 5;
            btnMulti.Text = "*";
            btnMulti.UseVisualStyleBackColor = true;
            btnMulti.Click += btnMulti_Click;
            // 
            // btnDiv
            // 
            btnDiv.Font = new Font("Segoe UI", 12F);
            btnDiv.Location = new Point(359, 272);
            btnDiv.Margin = new Padding(4);
            btnDiv.Name = "btnDiv";
            btnDiv.Size = new Size(82, 52);
            btnDiv.TabIndex = 6;
            btnDiv.Text = "/";
            btnDiv.UseVisualStyleBackColor = true;
            btnDiv.Click += btnDiv_Click;
            // 
            // lblNum1
            // 
            lblNum1.AutoSize = true;
            lblNum1.Font = new Font("Segoe UI", 12F);
            lblNum1.Location = new Point(31, 59);
            lblNum1.Margin = new Padding(4, 0, 4, 0);
            lblNum1.Name = "lblNum1";
            lblNum1.Size = new Size(81, 21);
            lblNum1.TabIndex = 6;
            lblNum1.Text = "Número 1";
            // 
            // lblNum2
            // 
            lblNum2.AutoSize = true;
            lblNum2.Font = new Font("Segoe UI", 12F);
            lblNum2.Location = new Point(31, 109);
            lblNum2.Margin = new Padding(4, 0, 4, 0);
            lblNum2.Name = "lblNum2";
            lblNum2.Size = new Size(81, 21);
            lblNum2.TabIndex = 7;
            lblNum2.Text = "Número 2";
            // 
            // lblResult
            // 
            lblResult.AutoSize = true;
            lblResult.Font = new Font("Segoe UI", 12F);
            lblResult.Location = new Point(28, 190);
            lblResult.Margin = new Padding(4, 0, 4, 0);
            lblResult.Name = "lblResult";
            lblResult.Size = new Size(79, 21);
            lblResult.TabIndex = 8;
            lblResult.Text = "Resultado";
            // 
            // txtNum1
            // 
            txtNum1.Location = new Point(141, 56);
            txtNum1.Margin = new Padding(4);
            txtNum1.Name = "txtNum1";
            txtNum1.Size = new Size(127, 29);
            txtNum1.TabIndex = 1;
            txtNum1.Validating += txtNum1_Validating;
            // 
            // txtNum2
            // 
            txtNum2.Location = new Point(141, 106);
            txtNum2.Margin = new Padding(4);
            txtNum2.Name = "txtNum2";
            txtNum2.Size = new Size(127, 29);
            txtNum2.TabIndex = 2;
            txtNum2.Validating += txtNum2_Validating;
            // 
            // txtResult
            // 
            txtResult.Enabled = false;
            txtResult.Location = new Point(141, 188);
            txtResult.Margin = new Padding(4);
            txtResult.Name = "txtResult";
            txtResult.Size = new Size(127, 29);
            txtResult.TabIndex = 99;
            txtResult.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(9F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(609, 409);
            Controls.Add(txtResult);
            Controls.Add(txtNum2);
            Controls.Add(txtNum1);
            Controls.Add(lblResult);
            Controls.Add(lblNum2);
            Controls.Add(lblNum1);
            Controls.Add(btnDiv);
            Controls.Add(btnMulti);
            Controls.Add(btnSub);
            Controls.Add(btnAdd);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Font = new Font("Segoe UI", 12F);
            Margin = new Padding(4);
            Name = "Form1";
            Text = "Melhor calculadora já vista";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnLimpar;
        private Button btnSair;
        private Button btnAdd;
        private Button btnSub;
        private Button btnMulti;
        private Button btnDiv;
        private Label lblNum1;
        private Label lblNum2;
        private Label lblResult;
        private TextBox txtNum1;
        private TextBox txtNum2;
        private TextBox txtResult;
    }
}
