namespace pCalc
{
    public partial class Form1 : Form
    {
        double Num1, Num2, Resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtNum1_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!double.TryParse(txtNum1.Text, out Num1))
            {
                MessageBox.Show("Insira um valor.", "Aten��o", 
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                e.Cancel = true;
                txtNum1.Focus();
            }

        }
        private void txtNum2_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!double.TryParse(txtNum2.Text, out Num2))
            {
                MessageBox.Show("Insira um valor.", "Aten��o",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                e.Cancel = true;
                txtNum2.Focus();
            }

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Resultado = Num1 + Num2;
            txtResult.Text = Resultado.ToString();
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            Resultado = Num1 - Num2;
            txtResult.Text = Resultado.ToString();
        }

        private void btnMulti_Click(object sender, EventArgs e)
        {
            Resultado = Num1 * Num2;
            txtResult.Text = Resultado.ToString();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (Num2 == 0)
            {
                MessageBox.Show("N�o � poss�vel realizar divis�es por 0.", "Erro", 
                MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNum2.Focus();

            }
            else
            {
                Resultado = Num1 / Num2;
                txtResult.Text = Resultado.ToString();
            }

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtResult.Text = "";
            txtNum2.Text = "";
            txtNum1.Text = "";
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
