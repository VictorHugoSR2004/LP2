﻿namespace pSalario
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNome = new Label();
            lblSalBruto = new Label();
            lblFilhos = new Label();
            btnVerificar = new Button();
            mskbxSalBruto = new MaskedTextBox();
            nupFilhos = new NumericUpDown();
            lblAliINSS = new Label();
            lblAliIRPF = new Label();
            lblSalFamilia = new Label();
            lblSalLiqui = new Label();
            lblDescINSS = new Label();
            lblDescIRPF = new Label();
            txtAliINSS = new TextBox();
            txtAliIRPF = new TextBox();
            txtSalFamilia = new TextBox();
            txtSalLiqui = new TextBox();
            txtDescINSS = new TextBox();
            txtDescIRPF = new TextBox();
            btnLimpar = new Button();
            btnSair = new Button();
            txtNome = new TextBox();
            ((System.ComponentModel.ISupportInitialize)nupFilhos).BeginInit();
            SuspendLayout();
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Italic);
            lblNome.Location = new Point(30, 35);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(138, 20);
            lblNome.TabIndex = 0;
            lblNome.Text = "Nome Funcionário";
            // 
            // lblSalBruto
            // 
            lblSalBruto.AutoSize = true;
            lblSalBruto.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Italic);
            lblSalBruto.Location = new Point(29, 65);
            lblSalBruto.Name = "lblSalBruto";
            lblSalBruto.Size = new Size(101, 20);
            lblSalBruto.TabIndex = 1;
            lblSalBruto.Text = "Salário Bruto";
            // 
            // lblFilhos
            // 
            lblFilhos.AutoSize = true;
            lblFilhos.Font = new Font("Microsoft Sans Serif", 12F);
            lblFilhos.Location = new Point(29, 96);
            lblFilhos.Name = "lblFilhos";
            lblFilhos.Size = new Size(133, 20);
            lblFilhos.TabIndex = 2;
            lblFilhos.Text = "Número de Filhos";
            // 
            // btnVerificar
            // 
            btnVerificar.Font = new Font("Arial Rounded MT Bold", 15F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnVerificar.Location = new Point(180, 153);
            btnVerificar.Name = "btnVerificar";
            btnVerificar.Size = new Size(173, 81);
            btnVerificar.TabIndex = 3;
            btnVerificar.Text = "Verificar Desconto";
            btnVerificar.UseVisualStyleBackColor = true;
            btnVerificar.Click += btnVerificar_Click;
            // 
            // mskbxSalBruto
            // 
            mskbxSalBruto.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            mskbxSalBruto.Location = new Point(186, 64);
            mskbxSalBruto.Mask = "99999.99";
            mskbxSalBruto.Name = "mskbxSalBruto";
            mskbxSalBruto.Size = new Size(126, 21);
            mskbxSalBruto.TabIndex = 5;
            mskbxSalBruto.Validated += mskbxSalBruto_Validated;
            // 
            // nupFilhos
            // 
            nupFilhos.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            nupFilhos.Location = new Point(186, 95);
            nupFilhos.Name = "nupFilhos";
            nupFilhos.Size = new Size(33, 21);
            nupFilhos.TabIndex = 6;
            // 
            // lblAliINSS
            // 
            lblAliINSS.AutoSize = true;
            lblAliINSS.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblAliINSS.Location = new Point(14, 281);
            lblAliINSS.Name = "lblAliINSS";
            lblAliINSS.Size = new Size(121, 18);
            lblAliINSS.TabIndex = 7;
            lblAliINSS.Text = "Aliquiota INSS";
            // 
            // lblAliIRPF
            // 
            lblAliIRPF.AutoSize = true;
            lblAliIRPF.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblAliIRPF.Location = new Point(14, 329);
            lblAliIRPF.Name = "lblAliIRPF";
            lblAliIRPF.Size = new Size(116, 18);
            lblAliIRPF.TabIndex = 8;
            lblAliIRPF.Text = "Aliquota IRPF";
            // 
            // lblSalFamilia
            // 
            lblSalFamilia.AutoSize = true;
            lblSalFamilia.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblSalFamilia.Location = new Point(14, 372);
            lblSalFamilia.Name = "lblSalFamilia";
            lblSalFamilia.Size = new Size(124, 18);
            lblSalFamilia.TabIndex = 9;
            lblSalFamilia.Text = "Salário Família";
            // 
            // lblSalLiqui
            // 
            lblSalLiqui.AutoSize = true;
            lblSalLiqui.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblSalLiqui.Location = new Point(14, 415);
            lblSalLiqui.Name = "lblSalLiqui";
            lblSalLiqui.Size = new Size(126, 18);
            lblSalLiqui.TabIndex = 10;
            lblSalLiqui.Text = "Salário Liquido";
            // 
            // lblDescINSS
            // 
            lblDescINSS.AutoSize = true;
            lblDescINSS.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblDescINSS.Location = new Point(266, 281);
            lblDescINSS.Name = "lblDescINSS";
            lblDescINSS.Size = new Size(132, 18);
            lblDescINSS.TabIndex = 11;
            lblDescINSS.Text = "Desconto  INSS";
            // 
            // lblDescIRPF
            // 
            lblDescIRPF.AutoSize = true;
            lblDescIRPF.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblDescIRPF.Location = new Point(266, 326);
            lblDescIRPF.Name = "lblDescIRPF";
            lblDescIRPF.Size = new Size(127, 18);
            lblDescIRPF.TabIndex = 12;
            lblDescIRPF.Text = "Desconto IRPF";
            // 
            // txtAliINSS
            // 
            txtAliINSS.Enabled = false;
            txtAliINSS.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtAliINSS.Location = new Point(149, 281);
            txtAliINSS.Name = "txtAliINSS";
            txtAliINSS.Size = new Size(100, 21);
            txtAliINSS.TabIndex = 13;
            // 
            // txtAliIRPF
            // 
            txtAliIRPF.Enabled = false;
            txtAliIRPF.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtAliIRPF.Location = new Point(149, 326);
            txtAliIRPF.Name = "txtAliIRPF";
            txtAliIRPF.Size = new Size(100, 21);
            txtAliIRPF.TabIndex = 14;
            // 
            // txtSalFamilia
            // 
            txtSalFamilia.Enabled = false;
            txtSalFamilia.Font = new Font("Microsoft Sans Serif", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtSalFamilia.Location = new Point(149, 372);
            txtSalFamilia.Name = "txtSalFamilia";
            txtSalFamilia.Size = new Size(100, 20);
            txtSalFamilia.TabIndex = 15;
            // 
            // txtSalLiqui
            // 
            txtSalLiqui.Enabled = false;
            txtSalLiqui.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtSalLiqui.Location = new Point(149, 415);
            txtSalLiqui.Name = "txtSalLiqui";
            txtSalLiqui.Size = new Size(100, 21);
            txtSalLiqui.TabIndex = 16;
            // 
            // txtDescINSS
            // 
            txtDescINSS.Enabled = false;
            txtDescINSS.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtDescINSS.Location = new Point(408, 281);
            txtDescINSS.Name = "txtDescINSS";
            txtDescINSS.Size = new Size(100, 21);
            txtDescINSS.TabIndex = 17;
            // 
            // txtDescIRPF
            // 
            txtDescIRPF.Enabled = false;
            txtDescIRPF.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtDescIRPF.Location = new Point(408, 328);
            txtDescIRPF.Name = "txtDescIRPF";
            txtDescIRPF.Size = new Size(100, 21);
            txtDescIRPF.TabIndex = 18;
            // 
            // btnLimpar
            // 
            btnLimpar.BackColor = SystemColors.ActiveCaption;
            btnLimpar.Location = new Point(287, 389);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(75, 23);
            btnLimpar.TabIndex = 19;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = false;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.BackColor = Color.FromArgb(192, 0, 0);
            btnSair.Location = new Point(433, 389);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(75, 23);
            btnSair.TabIndex = 20;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = false;
            btnSair.Click += btnSair_Click;
            // 
            // txtNome
            // 
            txtNome.Location = new Point(186, 32);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(291, 23);
            txtNome.TabIndex = 21;
            txtNome.KeyPress += txtNome_KeyPress;
            txtNome.Validating += txtNome_Validating;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(586, 450);
            Controls.Add(txtNome);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(txtDescIRPF);
            Controls.Add(txtDescINSS);
            Controls.Add(txtSalLiqui);
            Controls.Add(txtSalFamilia);
            Controls.Add(txtAliIRPF);
            Controls.Add(txtAliINSS);
            Controls.Add(lblDescIRPF);
            Controls.Add(lblDescINSS);
            Controls.Add(lblSalLiqui);
            Controls.Add(lblSalFamilia);
            Controls.Add(lblAliIRPF);
            Controls.Add(lblAliINSS);
            Controls.Add(nupFilhos);
            Controls.Add(mskbxSalBruto);
            Controls.Add(btnVerificar);
            Controls.Add(lblFilhos);
            Controls.Add(lblSalBruto);
            Controls.Add(lblNome);
            Name = "Form1";
            Text = "Programa Salário";
            ((System.ComponentModel.ISupportInitialize)nupFilhos).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNome;
        private Label lblSalBruto;
        private Label lblFilhos;
        private Button btnVerificar;
        private MaskedTextBox mskbxSalBruto;
        private NumericUpDown nupFilhos;
        private Label lblAliINSS;
        private Label lblAliIRPF;
        private Label lblSalFamilia;
        private Label lblSalLiqui;
        private Label lblDescINSS;
        private Label lblDescIRPF;
        private TextBox txtAliINSS;
        private TextBox txtAliIRPF;
        private TextBox txtSalFamilia;
        private TextBox txtSalLiqui;
        private TextBox txtDescINSS;
        private TextBox txtDescIRPF;
        private Button btnLimpar;
        private Button btnSair;
        private TextBox txtNome;
    }
}
