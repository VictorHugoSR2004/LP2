using Microsoft.VisualBasic.Logging;
using System.ComponentModel;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace pSalario
{
    public partial class Form1 : Form
    {
        double SalBruto, DescINSS = 0, DescIRPF = 0, SalFamilia, SalLiquido;
        public Form1()
        {
            InitializeComponent();
        }
        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAliINSS.Text = "";
            txtAliIRPF.Text = "";
            txtDescINSS.Text = "";
            txtDescIRPF.Text = "";
            txtSalFamilia.Text = "";
            txtSalLiqui.Text = "";
            txtNome.Text = "";
            mskbxSalBruto.Text = "";
            nupFilhos.Value = 0;
            mskbxSalBruto.BackColor = Color.White;
        }
        private void txtNome_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNome.Text))
            {
                MessageBox.Show("Digite seu nome!", "Aten��o",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsNumber(e.KeyChar) || Char.IsPunctuation(e.KeyChar))
            {
                MessageBox.Show("Caracter inv�lido", "Aten��o",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                SendKeys.Send("{BACKSPACE}");
            }
        }
        private void mskbxSalBruto_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxSalBruto.Text, out SalBruto))
            {
                MessageBox.Show("Insira o sal�rio corretamente", "Aten��o",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                mskbxSalBruto.BackColor = Color.LightSeaGreen;
            }
        }
        private void btnVerificar_Click(object sender, EventArgs e)
        {
            //INSS
            if (SalBruto <= 800.47)
            {
                txtAliINSS.Text = "7.65%";
                DescINSS = 0.0765 * SalBruto;
            }
            else if (SalBruto >= 800.48 && SalBruto <= 1050)
            {
                txtAliINSS.Text = "8.65%";
                DescINSS = 0.0865 * SalBruto;
            }
            else if (SalBruto >= 1050.01 && SalBruto <= 1400.77)
            {
                txtAliINSS.Text = "9.00%";
                DescINSS = 0.09 * SalBruto;
            }
            else if (SalBruto >= 1400.78 && SalBruto <= 2801.56)
            {
                txtAliINSS.Text = "11.00%";
                DescINSS = 0.11 * SalBruto;
            }
            else if (SalBruto > 2801.56)
            {
                txtAliINSS.Text = "Teto";
                DescINSS = 308.17;
            }

            //IRPF
            if (SalBruto <= 1257.12)
            {
                txtAliIRPF.Text = "Isento";
                DescIRPF = 0;
            }
            else if (SalBruto >= 1257.13 && SalBruto <= 2518.08)
            {
                txtAliIRPF.Text = "15.00%";
                DescIRPF = 0.15 * SalBruto;
            }
            else if (SalBruto > 2512.08)
            {
                txtAliIRPF.Text = "27.50%";
                DescIRPF = 0.275 * SalBruto;
            }

            // Sal�rio familia
            if (SalBruto <= 435.52)
            {
                SalFamilia = Convert.ToDouble(nupFilhos.Value);
                SalFamilia = 22.33 * SalFamilia;
            }
            else if (SalBruto >= 435.53 && SalBruto <= 654.61)
            {
                SalFamilia = Convert.ToDouble(nupFilhos.Value);
                SalFamilia = 15.74 * SalFamilia;
            }
            else
                SalFamilia = 0;

            SalLiquido = SalBruto - DescINSS - DescIRPF + SalFamilia;

            //exibe os valores
            txtSalLiqui.Text = SalLiquido.ToString("F");
            txtSalFamilia.Text = SalFamilia.ToString("F");
            txtDescIRPF.Text = DescINSS.ToString("F");
            txtDescINSS.Text = DescIRPF.ToString("F");
        }
    }
}
