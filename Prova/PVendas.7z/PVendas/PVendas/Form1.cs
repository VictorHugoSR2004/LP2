﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVendas
{
    // Maria Gabriela Viana & Victor Hugo Sanches Rodrigues

    public partial class Form1 : Form
    {
        private int GetNValue() //função para verificar o ultimo digito do RA
        {
            int ultimoDigitoRA = 7; // RA: 0030482321027
            int N;

            if (ultimoDigitoRA == 0 || ultimoDigitoRA == 1)
            {
                N = 2;
            }
            else
            {
                N = ultimoDigitoRA;
            }

            return N;
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int n = GetNValue();
            string[,] vendido = new string[n, 4];
            double aux, totalmes = 0, totalgeral = 0;

            for (int c = 0; c < vendido.GetLength(0); c++)
            {
                for (int d = 0; d < vendido.GetLength(1); d++)
                {
                    vendido[c, d] = Interaction.InputBox("Insira o total vendido no mês " + (c + 1) + " na semana " + (d + 1));
                    if (!double.TryParse(vendido[c, d], out aux))
                    {
                        MessageBox.Show("Insira um valor válido!", "Atenção",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        d--;
                    }
                    else
                    {
                        if (aux < 0)
                        {
                            MessageBox.Show("Insira um valor maior ou igual a 0!", "Atenção",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            d--;
                        }
                        else
                        {
                            lstbxMes.Items.Add("Total do mês: " +  (c + 1) + " Semana: " + (d + 1) + " " + aux.ToString("N2"));
                            totalmes += aux;
                            totalgeral += aux;
                        }
                    }
                }
                lstbxMes.Items.Add(">> Total Mês: " + totalmes.ToString("C2"));
                lstbxMes.Items.Add("***************************************************************************************************");
                totalmes = 0;
            }
            lstbxMes.Items.Add(">> Total Geral: " + totalgeral.ToString("C2"));
            lstbxMes.Items.Add(" ");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxMes.Items.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
